import { Component, OnInit } from '@angular/core';
import { HelperService } from 'src/app/services/helper.service';

@Component({
  selector: 'app-hero',
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.scss']
})
export class HeroComponent implements OnInit {

  constructor(private helperService: HelperService) { }

  ngOnInit(): void {
  }

  navigate(url: string):void {
    this.helperService.goto(url)
  }

}
