import {Component, OnInit} from '@angular/core'
import {HelperService} from 'src/app/services/helper.service'
import {Product} from 'src/app/types/product'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  products: Product[] = []

  constructor(private helperService: HelperService) {}

  ngOnInit(): void {
    this.helperService.getProducts().subscribe((data: Product[]) => {
      this.products = data
    })
  }
}
