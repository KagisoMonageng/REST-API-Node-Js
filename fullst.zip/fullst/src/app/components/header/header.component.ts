import {Component, OnInit} from '@angular/core'
import {Location} from '@angular/common'

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  showHeader = false
  showMenu = false

  constructor(private Location: Location) {}

  ngOnInit(): void {
    this.showHeader = this.Location.path() === '/hero' ? false : true
  }

  onToggleMenu() {
    this.showMenu = !this.showMenu
  }
}
